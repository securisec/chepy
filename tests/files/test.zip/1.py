from chepy import Chepy
# from prettyprinter import cpprint as print

c = Chepy('/tmp/a.zip')

print(
    c.load_file().zip_info().get_by_index(0).get_by_key()
)