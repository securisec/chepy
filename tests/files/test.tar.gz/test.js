// comment

function namedFunction(argument1, argument2) {
  return 
}

var es6function = (vars) => {
  /* some 
  * comment
  */
}

/**
 * another multline
 * comment
 */